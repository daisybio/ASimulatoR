library(testthat)
library(BiocFileCache)

test_check("BiocFileCache")
