library(testthat)
library(AnnotationFilter)

test_check("AnnotationFilter")
