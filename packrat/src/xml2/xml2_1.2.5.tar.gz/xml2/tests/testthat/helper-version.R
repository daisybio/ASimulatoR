cat("This is libxml2 version", as.character(xml2:::libxml2_version()), "\n")
