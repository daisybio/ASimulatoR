# IdeogramTrack

# GenomeAxisTrack
# gtrack <- GenomeAxisTrack()

# DataTrack

# AnnotationTrack

# GeneRegionTrack

# BiomartGeneRegionTrack

# DetailsAnnotationTrack

# SequenceTrack

# AlignmentsTrack

# HighlightTrack

# OverlayTrack