[<img src="https://www.bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="200" align="right"/>](https://bioconductor.org/)

_GenomicAlignments_ is an R/Bioconductor package for representing and manipulating short genomic alignments (typically aligned reads).

See https://bioconductor.org/packages/GenomicAlignments for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

